const express = require("express");
const bodyParser = require("body-parser");
const sequelize = require("./config/db");
require("dotenv").config();

const doctorRoutes = require("./routes/doctorRoutes");

const app = express();
app.use(bodyParser.json());


app.use("/api/doctor", doctorRoutes);


sequelize.authenticate()
  .then(() => console.log("Database connected"))
  .catch(err => console.log("DB error:", err));

sequelize.sync({ alter: true }).then(() => console.log("Tables synced"));


app.listen(process.env.PORT, () => console.log(`Server running on port ${process.env.PORT}`));
