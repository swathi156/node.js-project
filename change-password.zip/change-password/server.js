const express = require("express");
const sequelize = require("./config/db");
const userRoutes = require("./routes/userRoutes");

require("dotenv").config();
const app = express();

console.log("🚀 Starting server..."); 

app.use(express.json());

// Routes
app.use("/api/users", userRoutes);

// DB Sync
sequelize.sync({ alter: true })
  .then(() => {
    console.log("✅ Database synced");
  })
  .catch(err => {
    console.error("❌ Database sync failed:", err);
  });

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`✅ Server running on port ${PORT}`));
