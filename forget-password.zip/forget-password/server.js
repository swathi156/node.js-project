const express = require("express");
const app = express();
const sequelize = require("./config/db");
const authRoutes = require("./routes/auth");
require("dotenv").config();

app.use(express.json());
app.use("/api/auth", authRoutes);

sequelize.sync({ alter: true })
  .then(() => console.log("✅ Tables synced"))
  .catch(err => console.log("❌ DB Error:", err));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
