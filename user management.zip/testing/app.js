require('dotenv').config();
const express = require('express');
const app = express();
const sequelize = require('./config/db');

const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');


app.use(express.json());
app.use(express.urlencoded({ extended: true })); 


app.use('/uploads', express.static('uploads'));


app.get('/', (req, res) => res.send('Server up. Use /api/auth and /api/users'));


app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);

const PORT = process.env.PORT || 5000;

(async () => {
  try {
    await sequelize.authenticate();
    console.log('Database connected');

    await sequelize.sync({ alter: true });
    console.log('Models synced');

    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('Unable to start server:', err);
  }
})();
