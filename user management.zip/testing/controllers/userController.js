const User = require('../models/user');
const bcrypt = require('bcrypt');
require('dotenv').config();

const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS || '10');

// 📌 Create user (admin use case)
exports.createUser = async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ message: "All fields are required" });
    }

    // Check if email exists
    const existing = await User.findOne({ where: { email } });
    if (existing) return res.status(400).json({ message: "Email already registered" });

    // Hash password
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    // Save user
    const user = await User.create({ name, email, password: hashedPassword });

    const { password: _pw, ...userData } = user.toJSON();
    return res.status(201).json({ message: "User created successfully", user: userData });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Server error" });
  }
};

// 📌 Get all users
exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.findAll();

    // Convert file paths to URLs
    const usersWithFileUrl = users.map(u => {
      const user = u.toJSON();
      if (user.file) {
        user.file = `${req.protocol}://${req.get('host')}/uploads/${user.file}`;
      }
      return user;
    });

    return res.json({ users: usersWithFileUrl });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
};

// 📌 Update user
exports.updateUser = async (req, res) => {
  try {
    const id = req.params.id;
    const { name, email, password } = req.body;
    const user = await User.findByPk(id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    if (email && email !== user.email) {
      const exists = await User.findOne({ where: { email } });
      if (exists) return res.status(400).json({ message: 'Email already in use' });
    }

    if (password) user.password = await bcrypt.hash(password, saltRounds);
    if (name) user.name = name;
    if (email) user.email = email;

    await user.save();

    const { password: _pw, ...userData } = user.toJSON();
    if (userData.file) {
      userData.file = `${req.protocol}://${req.get('host')}/uploads/${userData.file}`;
    }

    return res.json({ message: 'User updated', user: userData });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
};

// 📌 Delete user
exports.deleteUser = async (req, res) => {
  try {
    const id = req.params.id;
    const user = await User.findByPk(id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    await user.destroy();
    return res.json({ message: 'User deleted' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
};

// 📌 Upload file
exports.uploadFile = async (req, res) => {
  try {
    const id = req.params.id;
    const user = await User.findByPk(id);
    if (!user) return res.status(404).json({ message: 'User not found' });

    if (!req.file) return res.status(400).json({ message: 'No file uploaded' });

    // Save only the filename in DB
    user.file = req.file.filename;
    await user.save();

    // Build file URL
    const fileUrl = `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`;

    return res.json({ message: 'File uploaded successfully', file: fileUrl });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
};
