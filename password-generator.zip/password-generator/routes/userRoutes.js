const express = require("express");
const router = express.Router();
const User = require("../models/user");
const nodemailer = require("nodemailer");


function generatePassword(length = 8) {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";
  return Array.from({ length }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
}


const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});


router.post("/register", async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) return res.status(400).json({ message: "Email is required" });

    const password = generatePassword();

    
    const user = await User.create({ email, password });

    
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: email,
      subject: "Your Auto-Generated Password",
      text: `Hello, your password is: ${password}`,
    });

    res.json({ message: "Password generated and sent to email", user });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.delete("/delete", async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: "Email is required" });

    const deleted = await User.destroy({ where: { email } });

    if (!deleted) return res.status(404).json({ error: "User not found" });

    res.json({ message: `User with email ${email} deleted` });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
module.exports = router;
