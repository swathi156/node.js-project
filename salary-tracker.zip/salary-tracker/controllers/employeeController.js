const Employee = require("../models/employee");
const SalaryHistory = require("../models/salaryHistory");

exports.createEmployee = async (req, res) => {
  try {
    const { name, email, designation, department, salary } = req.body;

    
    if (!name || !email || !designation || !department || !salary) {
      return res.status(400).json({ message: "All fields are required" });
    }

    
    const existingEmployee = await Employee.findOne({ where: { email } });
    if (existingEmployee) {
      return res.status(400).json({ message: "Employee with this email already exists" });
    }

    T
    const employee = await Employee.create({
      name,
      email,
      designation,
      department,
      salary,
      createdBy: req.user.id,
      updatedBy: req.user.id,
    });

    
    await SalaryHistory.create({
      employeeId: employee.id,
      oldSalary: 0,      
      newSalary: salary,
      updatedBy: req.user.id,
    });

    res.status(201).json({ message: "Employee created successfully", employee });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: err.message });
  }
};


exports.updateEmployee = async (req, res) => {
  try {
    const employee = await Employee.findByPk(req.params.id);
    if (!employee) return res.status(404).json({ message: "Employee not found" });

    const { name, email, designation, department, salary } = req.body;

    
    if (salary && parseFloat(salary) !== parseFloat(employee.salary)) {
      await SalaryHistory.create({
        employeeId: employee.id,
        oldSalary: employee.salary,
        newSalary: salary,
        updatedBy: req.user.id,
      });
    }

    
    await employee.update({
      name: name || employee.name,
      email: email || employee.email,
      designation: designation || employee.designation,
      department: department || employee.department,
      salary: salary || employee.salary,
      updatedBy: req.user.id,
    });

    res.json({ message: "Employee updated successfully", employee });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: err.message });
  }
};


exports.getAllEmployees = async (req, res) => {
  try {
    const employees = await Employee.findAll();
    res.json(employees);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};


exports.getEmployeeById = async (req, res) => {
  try {
    const employee = await Employee.findByPk(req.params.id);
    if (!employee) return res.status(404).json({ message: "Employee not found" });
    res.json(employee);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};


exports.deleteEmployee = async (req, res) => {
  try {
    const employee = await Employee.findByPk(req.params.id);
    if (!employee) return res.status(404).json({ message: "Employee not found" });

    await employee.destroy();
    res.json({ message: "Employee deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};


exports.getSalaryHistory = async (req, res) => {
  try {
    const employeeId = req.params.id;
    const history = await SalaryHistory.findAll({
      where: { employeeId },
      order: [["createdAt", "DESC"]],
    });
    res.json({ salaryHistory: history });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
