const SalaryHistory = require("../models/salaryHistory");

exports.getSalaryHistory = async (req, res) => {
  try {
    const history = await SalaryHistory.findAll({
      where: { employeeId: req.params.id },
      order: [["createdAt", "DESC"]],
    });

    res.json({ salaryHistory: history });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
