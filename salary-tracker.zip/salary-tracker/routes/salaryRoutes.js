const express = require("express");
const router = express.Router();
const salaryController = require("../controllers/salaryController");
const authMiddleware = require("../middleware/authMiddleware");

router.get("/:id/history", authMiddleware, salaryController.getSalaryHistory);

module.exports = router;
