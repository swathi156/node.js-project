const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");
const Employee = require("./employee");
const User = require("./user");

const SalaryHistory = sequelize.define("SalaryHistory", {
  oldSalary: { type: DataTypes.DECIMAL(10, 2), allowNull: false },
  newSalary: { type: DataTypes.DECIMAL(10, 2), allowNull: false },
  updatedBy: { type: DataTypes.INTEGER },
});

SalaryHistory.belongsTo(Employee, { foreignKey: "employeeId" });
SalaryHistory.belongsTo(User, { foreignKey: "updatedBy", as: "updater" });

module.exports = SalaryHistory;
