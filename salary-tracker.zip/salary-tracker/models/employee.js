const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");
const User = require("./user");

const Employee = sequelize.define("Employee", {
  name: { type: DataTypes.STRING, allowNull: false },
  email: { type: DataTypes.STRING, allowNull: false },
  designation: { type: DataTypes.STRING, allowNull: false },
  department: { type: DataTypes.STRING, allowNull: false },
  salary: { type: DataTypes.DECIMAL(10, 2), allowNull: false },
  createdBy: { type: DataTypes.INTEGER },
  updatedBy: { type: DataTypes.INTEGER },
});

Employee.belongsTo(User, { foreignKey: "createdBy", as: "creator" });
Employee.belongsTo(User, { foreignKey: "updatedBy", as: "updater" });

module.exports = Employee;
