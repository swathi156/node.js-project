const sequelize = require("../config/db");
const User = require("./user");
const Employee = require("./employee");
const SalaryHistory = require("./salaryHistory");

// Employee associations
Employee.belongsTo(User, { as: "createdByUser", foreignKey: "created_by" });
Employee.belongsTo(User, { as: "updatedByUser", foreignKey: "updated_by" });

// SalaryHistory associations
SalaryHistory.belongsTo(Employee, { as: "employeeRef", foreignKey: "employee_id" });
SalaryHistory.belongsTo(User, { as: "salaryUpdatedBy", foreignKey: "updated_by" });

// Export models + sequelize
module.exports = {
  sequelize,
  User,
  Employee,
  SalaryHistory,
};
